package Global

import Global.ServiceCenter.studentServiceCode

object GlobalVariables:
  val serviceCode: String = studentServiceCode
