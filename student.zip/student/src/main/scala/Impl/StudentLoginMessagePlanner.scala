package Impl

import cats.effect.IO
import io.circe.generic.auto._
import io.circe.syntax._
import Common.API.{PlanContext, Planner}
import Common.DBAPI.{readDBRows, readDBBoolean}
import Common.Object.SqlParameter
import Common.ServiceUtils.schemaName
import APIs.StudentAPI.{StudentLoginResponse}

case class StudentLoginMessagePlanner(
                                       userName: String,
                                       password: String,
                                       number: String,
                                       override val planContext: PlanContext
                                     ) extends Planner[String] {
  override def plan(using planContext: PlanContext): IO[String] = {
    // Attempt to validate the user by reading the rows from the database
    val checkUserExists = readDBBoolean(
      s"SELECT EXISTS(SELECT 1 FROM ${schemaName}.students WHERE user_name = ? OR number = ?)",
      List(
        SqlParameter("String", userName),
        SqlParameter("String", number)
      )
    )

    checkUserExists.flatMap { exists =>
      if (!exists) {
        IO.raiseError(new Exception("Invalid user"))
      } else {
        val checkPassword = readDBBoolean(
          s"SELECT EXISTS(SELECT 1 FROM ${schemaName}.students WHERE user_name = ? AND password = ?)",
          List(
            SqlParameter("String", userName),
            SqlParameter("String", password)
          )
        )

        checkPassword.flatMap { passwordValid =>
          if (!passwordValid) {
            IO.raiseError(new Exception("Wrong password"))
          } else {
            // Retrieve additional information
            readDBRows(
              s"SELECT user_name, number, volunteer_status, floor, section_number, seat_number, violation_count, volunteer_hours FROM ${schemaName}.students WHERE user_name = ? AND password = ? AND number = ?",
              List(
                SqlParameter("String", userName),
                SqlParameter("String", password),
                SqlParameter("String", number)
              )
            ).map { rows =>
              rows.headOption match {
                case Some(row) =>
                  val userNameOpt = row.hcursor.get[String]("user_name")
                  val numberOpt = row.hcursor.get[String]("number")
                  val volunteerStatusOpt = row.hcursor.get[String]("volunteer_status")
                  val floorOpt = row.hcursor.get[String]("floor")
                  val sectionNumberOpt = row.hcursor.get[String]("section_number")
                  val seatNumberOpt = row.hcursor.get[String]("seat_number")
                  val violationCountOpt = row.hcursor.get[String]("violation_count")
                  val volunteerHoursOpt = row.hcursor.get[String]("volunteer_hours")

                  // Check for missing fields
                  if (userNameOpt.isRight && numberOpt.isRight && volunteerStatusOpt.isRight && floorOpt.isRight && sectionNumberOpt.isRight && seatNumberOpt.isRight && violationCountOpt.isRight && volunteerHoursOpt.isRight) {
                    StudentLoginResponse(
                      valid = true,
                      Some(userNameOpt.getOrElse("")),
                      Some(numberOpt.getOrElse("")),
                      Some(volunteerStatusOpt.getOrElse("")),
                      Some(floorOpt.getOrElse("")),
                      Some(sectionNumberOpt.getOrElse("")),
                      Some(seatNumberOpt.getOrElse("")),
                      Some(violationCountOpt.getOrElse("")),
                      Some(volunteerHoursOpt.getOrElse(""))
                    ).asJson.noSpaces
                  } else {
                    s"""{"error": "Failed to retrieve all required fields"}"""
                  }
                case None =>
                  StudentLoginResponse(valid = true).asJson.noSpaces
              }
            }
          }
        }
      }
    }
  }
}
