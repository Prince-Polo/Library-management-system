package APIs.JobAPI

case class UpdateTaskStatusResponse(success: Boolean, message: String)