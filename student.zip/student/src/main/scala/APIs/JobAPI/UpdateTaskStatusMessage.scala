package APIs.JobAPI

case class UpdateTaskStatusMessage(jobId: Int, studentId: Int, status: Int)
