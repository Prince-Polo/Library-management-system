package APIs.JobAPI

case class IncompleteJobByStudentQueryResponse(jobs: List[JobInfo])
