package APIs.JobAPI

case class DeleteJobResponse(success: Boolean, message: String)