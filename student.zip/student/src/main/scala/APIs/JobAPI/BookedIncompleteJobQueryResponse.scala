package APIs.JobAPI

case class BookedIncompleteJobQueryResponse(jobs: List[JobInfo])
