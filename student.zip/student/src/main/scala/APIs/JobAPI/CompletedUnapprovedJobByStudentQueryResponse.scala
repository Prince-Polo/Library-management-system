package APIs.JobAPI

case class CompletedUnapprovedJobByStudentQueryResponse(jobs: List[JobInfo])
