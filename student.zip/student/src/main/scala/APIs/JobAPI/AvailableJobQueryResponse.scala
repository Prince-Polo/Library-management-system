package APIs.JobAPI

case class AvailableJobQueryResponse(jobs: List[JobInfo])
