package APIs.JobAPI

case class BookedCompletedUnapprovedJobQueryResponse(jobs: List[JobInfo])
