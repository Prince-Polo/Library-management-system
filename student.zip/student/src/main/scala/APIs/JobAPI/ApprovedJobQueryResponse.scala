package APIs.JobAPI

case class ApprovedJobQueryResponse(jobs: List[JobInfo])