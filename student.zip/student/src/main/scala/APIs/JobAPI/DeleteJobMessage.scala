package APIs.JobAPI

case class DeleteJobMessage(jobId: Int)

