package APIs.JobAPI

case class StudentInfo(studentId: String,status:Int)