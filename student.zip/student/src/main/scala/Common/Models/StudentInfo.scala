package Common.Models

case class StudentInfo()
