package Common.API

case class PlanContext(traceID:TraceID, transactionLevel: Int)
