package APIs.PatientAPI

case class StudentUnregisterMessage(number: String)
