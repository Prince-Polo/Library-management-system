package APIs.PatientAPI

case class StudentInfoMessage(number: String)
