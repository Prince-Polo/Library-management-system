package APIs.PatientAPI

case class StudentInfoResponse(userName: String, email: String, number: String)
