package Global

import Global.ServiceCenter.patientServiceCode

object GlobalVariables:
  val serviceCode:String=patientServiceCode
